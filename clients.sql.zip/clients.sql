-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2020 at 07:19 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clients`
--

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `id_res` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `timeslot` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`id_res`, `name`, `email`, `date`, `timeslot`) VALUES
(10, 'Test', 'test@gmail.com', '2020-12-16', '15:00PM-15:30PM'),
(11, 'Wael', 'waelalbasha99@gmail.com', '2020-12-16', '15:30PM-16:00PM'),
(12, 'Wael', 'waelalbasha99@gmail.com', '2020-12-24', '15:00PM-15:30PM'),
(13, 'Wael', 'waelalbasha99@gmail.com', '2020-12-23', '14:30PM-15:00PM'),
(14, 'Wael', 'waelalbasha99@gmail.com', '2020-12-23', '14:30PM-15:00PM'),
(15, 'Wael', 'waelalbasha99@gmail.com', '2020-12-25', '14:30PM-15:00PM'),
(16, 'Jad', 'Jad@gmail.com', '2020-12-17', '11:30AM-12:00PM'),
(17, 'Saeed', 'Saeed@gmail.com', '2020-12-17', '11:30AM-12:00PM');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `email` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`email`, `nom`, `password`, `type`) VALUES
('3abbes@gmail.com', '3abbes', 'userpass', 'Student'),
('ahmad@gmail.com', 'Ahmad', 'ahmad122', 'Not-Student'),
('aymanhajjar@gmail.com', 'ayman', 'userpass', 'Not-Student'),
('hasan-kotaich@gmail.com', 'Hasan', 'userpass', 'Student'),
('ja3far@gmail.com', 'ja3far', 'userpass', 'Not-Student'),
('Jad@gmail.com', 'Jad', 'jad123', 'Student'),
('mahdisalameh@gmail.com', 'Mahdi', 'userpass', 'Student'),
('mostapha@gmail.com', 'Mostapha', 'userpass', 'Student'),
('najlaojeimi@gmail.com', 'Najla', 'userpass', 'Student'),
('Raul@gmail.com', 'Raul', 'userpass', 'Not-Student'),
('Saeed@gmail.com', 'Saeed', 'userpass', 'Student'),
('test@gmail.com', 'Test', 'test123', 'Not-Student'),
('waelalbasha99@gmail.com', 'Wael', 'userpass', 'Student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`id_res`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `id_res` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
