<?php
session_start(); // Starting the session

if (isset($_GET['date'])) { //Getting the date chosen
    $date = $_GET['date'];
    $_SESSION['date'] = $date;
}
$duration = 30;
$cleanup = 0;
$start = "07:00";
$end = "20:00";


function timeslots($duration, $cleanup, $start, $end) // This is the function for displaying the timeslots from the $start"8:00" to $end"19:00" with a duration between "30 mins"
{
    $start = new DateTime($start);
    $end = new DateTime($end);
    $interval = new DateInterval("PT" . $duration . "M");
    $cleanupInterval = new DateInterval("PT" . $cleanup . "M");
    $slots = array();

    for ($intStart = $start; $intStart < $end; $intStart->add($interval)->add($cleanupInterval)) {
        $endPeriod = clone $intStart;
        $endPeriod->add($interval);
        if ($endPeriod > $end) {
            break;
        }
        $slots[] = $intStart->format("H:iA") . "-" . $endPeriod->format("H:iA");
    }
    return $slots;
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <link rel="stylesheet" href="/css/main.css">
</head>

<body>
    <div class="container">
        <h1 class="text-center">Book for Date: <?php echo date('m/d/Y', strtotime($date)); ?></h1><!-- Displaying the date chosen beside the title -->
        <hr>
        <div class="row">
            <form action="modal.php" method="post">
                <?php
                $timeslots = timeslots($duration, $cleanup, $start, $end);
                $timeslots = is_array($timeslots) ? $timeslots : array($timeslots);
                foreach ($timeslots as $ts) {
                ?>
                    <div class="col-md-2">
                        <div class="form-group">
                            <button type="submit" name="btnTimeSlot" class="btn btn-success book" data-toggle="modal" data-target="#myModal" data-timeslot="<?php echo $ts; ?>" value="<?php echo $ts; ?>"><?php echo $ts; ?></button>
                            <!-- Printing the timeslots as buttons that can access to the reservation-->
                        </div>
                    </div>

                <?php } ?>
            </form>
        </div>
    </div>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <script>
        // This a script to make when the book button is clicked
        $(".book").click(function() {
            var timeslot = $(this).attr('data-timeslot');
            $("#slot").html(timeslot);
            $("#timeslot").val(timeslot);
            $("#myModal").modal("show");
        })
    </script>
</body>

</html>