<?php
session_start();
if (isset($_REQUEST['btnLogin'])) { // If the login button is clicked
    $email = $_REQUEST['email']; // getting the email written in the textbox
    $pwd = $_REQUEST['password']; // getting the password written in the textbox
    if (isset($_REQUEST['chkMemo'])) {
        // if the checkbox for memo is clicked, the data will be saved in a cookie
        setcookie("email", "$email", mktime(0, 0, 0, 12, 31, 2020));
        setcookie("pwd", "$pwd", mktime(0, 0, 0, 12, 31, 2020));
    }
    require_once("connexion.php"); // requiring the connection
    $sql = "select nom,type from user where email='$email' and password='$pwd'";
    $res = mysqli_query($link, $sql);
    if (mysqli_num_rows($res) == 1) { // checking if the written email and opassword are correct in the database
        $ligne = mysqli_fetch_array($res);
        $_SESSION['email'] = $email;
        $_SESSION['nom'] = $ligne['nom'];
        $_SESSION['type'] = $ligne['type'];
        header("location:Home.php");
    } else
        echo "<script>alert('Email or password incorrect')</script>";
} else if (isset($_COOKIE['email'], $_COOKIE['pwd'])) {
    // saving them in a cookie
    $email = $_COOKIE['email'];
    $pwd = $_COOKIE['pwd'];
} else
    $email = $pwd = '';
?>



<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Store - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
</head>

<body style="background: linear-gradient(rgba(47, 23, 15, 0.65), rgba(47, 23, 15, 0.65)), url('assets/img/chops.jpg');">
    <h1 class="text-center text-white d-none d-lg-block site-heading"><span class="site-heading-lower">Barbershop brest</span></h1>
    <nav class="navbar navbar-light navbar-expand-lg bg-dark py-lg-4" id="mainNav">
        <div class="container"><a class="navbar-brand text-uppercase d-lg-none text-expanded" href="#">Brand</a><button data-toggle="collapse" data-target="#navbarResponsive" class="navbar-toggler" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="nav navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="Home.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About us</a></li>
                    <li class="nav-item"><a class="nav-link" href="products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="store.php">Date</a></li>
                    <li class="nav-item"><a class="nav-link" href="store-1.php">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="login-dark">
        <form method="post" style="text-align: center;">
            <h2 class="sr-only">Login Form</h2>
            <div class="illustration"><i class="icon ion-ios-locked-outline"></i></div>
            <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email" value="<?php echo $email ?>" autofocus="" required="" minlength="4" maxlength="40"></div>
            <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password" <?php echo $pwd ?>></div>
            <div class="form-check"><input class="form-check-input" type="checkbox" id="checkbox" name="chkMemo"><label class="form-check-label" for="checkbox">Remember me</label></div>
            <div class="form-group"><button class="btn btn-primary btn-block" name="btnLogin" type="submit">Log In</button></div>
            <div class="form-group"><a class="btn btn-primary" role="button" style="margin: 4px;height: 45px;width: 69px;" href="index-1.php">Signup</a></div>
        </form>
    </div>
    <section class="page-section about-heading">
        <div class="container">
            <div class="about-heading-content"></div>
        </div>
    </section>
    <footer class="footer text-faded text-center py-5">
        <div class="container">
            <p class="m-0 small">Copyright&nbsp;©&nbsp;Barbershop Brest 2020</p>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/smart-forms.min.js"></script>
    <script src="assets/js/current-day.js"></script>
</body>

</html>