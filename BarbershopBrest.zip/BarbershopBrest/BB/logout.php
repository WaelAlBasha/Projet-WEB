<!-- When the logout button is clicked,the location will be at the Home.php -->
<?php
session_start();
session_unset();
session_destroy();
header("location:Home.php");
?>