<?php
session_start(); //Start the session

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>About us - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
</head>

<body style="background: linear-gradient(rgba(47, 23, 15, 0.65), rgba(47, 23, 15, 0.65)), url('assets/img/chops.jpg');">
    <h1 class="text-center text-white d-none d-lg-block site-heading">
        <span class="text-primary site-heading-upper mb-3"></span>
        <span class="site-heading-lower">Barbershop brest</span>
        <span class="text-primary site-heading-upper mb-3"><?php if (isset($_SESSION['nom'])) echo "Welcome {$_SESSION['nom']}"  ?></span></h1>
    <!--When the user is logged in, His name will appear on every page with Welcome"his name" -->
    <nav class="navbar navbar-light navbar-expand-lg bg-dark py-lg-4" id="mainNav">
        <div class="container"><a class="navbar-brand text-uppercase d-lg-none text-expanded" href="#">Barbershop brest</a><button data-toggle="collapse" data-target="#navbarResponsive" class="navbar-toggler" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="nav navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="Home.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About us</a></li>
                    <li class="nav-item"><a class="nav-link" href="products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="store.php">Date</a></li>
                    <?php
                    if (isset($_SESSION['nom'])) { // If the client is logged in, He can reserve online
                        echo "<li class='nav-item'><a class='nav-link' href='reserve_online.php'>Reserve Online</a></li>";
                        echo "<li class='nav-item'><a class='nav-link' href='logout.php'>Logout</a></li>";
                    } else
                        echo "<li class='nav-item'><a class='nav-link' href='store-1.php'>Login</a></li>";
                    ?>

                </ul>
            </div>
        </div>
    </nav>
    <section class="page-section about-heading">
        <div class="container"><img class="img-fluid rounded about-heading-img mb-3 mb-lg-0" src="assets/img/55.jpg">
            <div class="about-heading-content">
                <div class="row">
                    <div class="col-lg-10 col-xl-9 mx-auto">
                        <div class="bg-faded rounded p-5">
                            <h2 class="section-heading mb-4"><span class="section-heading-lower">why it is worth ;)</span></h2>
                            <p></p>
                            <p class="mb-0"><span></span><span></span><span>Having inherited my passion for styling hair from my father I decided six years ago to make a living out of it and open my own barber shop. That's how the history of the 2 Rue de Siam started ! <br>I began as a small barber and one client after another I made my dream comes true. Now fully installed in Brest I devote myself full-time to the shop and welcome you six days a week. <br>My values : quality, efficiency, well-being and customer satisfaction! I always want to better myself for my clients and make them feel at home in my barber shop.<br>Adding to cuts, products like waxes and gels are available for sale.<br>Easy and reliable you can make an appointment directly on the website.<br>See you soon downtown Siam!</span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class="footer text-faded text-center py-5">
        <div class="container">
            <p class="m-0 small">Copyright&nbsp;©&nbsp;Barbershop Brest 2020</p>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/smart-forms.min.js"></script>
    <script src="assets/js/current-day.js"></script>
</body>

</html>