<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Store - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
</head>

<body style="background: linear-gradient(rgba(47, 23, 15, 0.65), rgba(47, 23, 15, 0.65)), url('assets/img/chops.jpg');">
    <h1 class="text-center text-white d-none d-lg-block site-heading">
        <span class="site-heading-lower">barbershop brest</span>
        <span class="text-primary site-heading-upper mb-3"><?php if (isset($_SESSION['nom'])) echo "Welcome {$_SESSION['nom']}"  ?></span></h1>
    <nav class="navbar navbar-light navbar-expand-lg bg-dark py-lg-4" id="mainNav">
        <div class="container"><a class="navbar-brand text-uppercase d-lg-none text-expanded" href="#">Brand</a><button data-toggle="collapse" data-target="#navbarResponsive" class="navbar-toggler" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="nav navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="Home.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About us</a></li>
                    <li class="nav-item"><a class="nav-link" href="products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="store.php">Date</a></li>
                    <li class="nav-item"><a class="nav-link" href="reserve_online.php">Reserve online</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <section class="page-section cta">
        <div class="container">
            <div class="row">
                <div class="col-xl-9 mx-auto">
                    <div class="cta-inner text-center rounded">
                        <?php if (isset($_SESSION['type']) && $_SESSION['type'] == 'Student') {

                            echo "<h2 class='section-heading mb-5'><span class='section-heading-lower'>We're Open</span></h2>
<ul class='list-unstyled mx-auto list-hours mb-5 text-left'>
    <li class='d-flex list-unstyled-item list-hours-item'>Hair Cuts<span class='ml-auto'>12.00 Euro</span></li>
    <li class='d-flex list-unstyled-item list-hours-item'>Boy's Haircut<span class='ml-auto'>8.00 Euro</span></li>
    <li class='d-flex list-unstyled-item list-hours-item'>Mostache Trim<span class='ml-auto'>4.80 Euro</span></li>
    <li class='d-flex list-unstyled-item list-hours-item'>Beard Trim&nbsp;<span class='ml-auto'>7.20 Euro</span></li>
    <li class='d-flex list-unstyled-item list-hours-item'>Sholder Massage<span class='ml-auto'>9.60 Euro</span></li>
    <li class='d-flex list-unstyled-item list-hours-item'>Cut and Design<span class='ml-auto'>16.00 Euro</span></li>
    <li class='d-flex list-unstyled-item list-hours-item'>Relaxing Shampoo<span class='ml-auto'>5.60 Euro</span></li>
</ul>
<p class='address mb-5'><em><strong>2 Rue Siam</strong></em></p>
<p class='address mb-0'><small></small></p><a class='btn btn-primary' role='button' href='Calendar.php'>Reserve Online !!</a>";
                        } else {
                            echo "<h2 class='section-heading mb-5'><span class='section-heading-lower'>We're Open</span></h2>
                            <ul class='list-unstyled mx-auto list-hours mb-5 text-left'>
                                <li class='d-flex list-unstyled-item list-hours-item'>Hair Cuts<span class='ml-auto'>15 Euro</span></li>
                                <li class='d-flex list-unstyled-item list-hours-item'>Boy's Haircut<span class='ml-auto'>10 Euro</span></li>
                                <li class='d-flex list-unstyled-item list-hours-item'>Mostache Trim<span class='ml-auto'>6 Euro</span></li>
                                <li class='d-flex list-unstyled-item list-hours-item'>Beard Trim&nbsp;<span class='ml-auto'>9 Euro</span></li>
                                <li class='d-flex list-unstyled-item list-hours-item'>Sholder Massage<span class='ml-auto'>12 Euro</span></li>
                                <li class='d-flex list-unstyled-item list-hours-item'>Cut and Design<span class='ml-auto'>20 Euro</span></li>
                                <li class='d-flex list-unstyled-item list-hours-item'>Relaxing Shampoo<span class='ml-auto'>7 Euro</span></li>
                            </ul>
                            <p class='address mb-5'><em><strong>2 Rue Siam</strong></em></p>
                            <p class='address mb-0'><small></small></p><a class='btn btn-primary' role='button' href='Calendar.php'>Reserve Online !!</a>";
                        } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="page-section about-heading">
        <div class="container">
            <div class="about-heading-content"></div>
        </div>
    </section>
    <footer class="footer text-faded text-center py-5">
        <div class="container">
            <p class="m-0 small">Copyright&nbsp;©&nbsp;Barbershop Brest 2020</p>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/smart-forms.min.js"></script>
    <script src="assets/js/current-day.js"></script>
</body>

</html>