<?php
session_start();
if (isset($_SESSION['date'])) {
    $date = $_SESSION['date'];
}

if (isset($_POST['submit'])) {
    $name = $_SESSION['nom'];
    $email = $_SESSION['email'];
    $timeslot = $_POST['timeslot'];
    //$mysqli = new mysqli('localhost', 'root', '', 'clients');
    require_once("connexion.php");
    //echo  "<script>alert('$name  $email $date  $timeslot')</script>";
    $sql = "insert into reservation (name,email,date,timeslot) values('$name','$email','$date','$timeslot')";
    //$sql = "INSERT INTO reservation([name], [email], [date], [timeslot]) VALUES ('{$_SESSION['nom']}','{$_SESSION['email']}','{$_SESSION['date']}','{$_SESSION['timeslot']}')";
    mysqli_query($link, $sql);
    if (mysqli_affected_rows($link) > 0) {
        //echo "<script>alert('Reserved !!')</script>";

        header("location:Home.php");
    } else {
        echo "<script>alert('user already exist')</script>";
    }


    /* $stmt = $mysqli->prepare("INSERT INTO reservation (nom, email,[date],timeslot) VALUES (?,?,?,?)");
    $stmt->bind_param('ssss', $name, $email, $date, $timeslot);
    $stmt->execute();
    $msg = "<div class='alert alert-success'>Booking Successfull</div>";
    $stmt->close();
    $mysqli->close();*/
}
?>




<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Store - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
</head>

<body style="background: linear-gradient(rgba(47, 23, 15, 0.65), rgba(47, 23, 15, 0.65)), url('assets/img/chops.jpg');">
    <h1 class="text-center text-white d-none d-lg-block site-heading"><span class="site-heading-lower">barbershop brest</span></h1>
    <section class="page-section cta">

        <div class="col-md-12">
            <form action="" method="POST">
                <div class="form-group">
                    <label for="">Timeslot</label>
                    <input required type="text" readonly name="timeslot" id="timeslot" class="form-control" value="<?php echo $_POST['btnTimeSlot'] ?>">
                </div>
                <div class="form-group">
                    <label for="">Name</label>
                    <input required type="text" name="name" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Email</label>
                    <input required type="email" name="email" class="form-control">
                </div>
                <div class="form-group pull-right">
                    <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                </div>
            </form>
        </div>
    </section>
    <section class="page-section about-heading">
        <div class="container">
            <div class="about-heading-content"></div>
        </div>
    </section>
    <footer class="footer text-faded text-center py-5">
        <div class="container">
            <p class="m-0 small">Copyright&nbsp;©&nbsp;Barbershop Brest 2020</p>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/smart-forms.min.js"></script>
    <script src="assets/js/current-day.js"></script>
</body>

</html>