<?php
session_start(); //Start the session

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Store - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
</head>

<body style="background: linear-gradient(rgba(47, 23, 15, 0.65), rgba(47, 23, 15, 0.65)), url('assets/img/chops.jpg');">
    <h1 class="text-center text-white d-none d-lg-block site-heading">
        <span class="text-primary site-heading-upper mb-3"></span>
        <span class="site-heading-lower">Barbershop brest</span>
        <span class="text-primary site-heading-upper mb-3"><?php if (isset($_SESSION['nom'])) echo "Welcome {$_SESSION['nom']}"  ?></span></h1>
    <!--When the user is logged in, His name will appear on every page with Welcome"his name" -->
    <nav class="navbar navbar-light navbar-expand-lg bg-dark py-lg-4" id="mainNav">
        <div class="container"><a class="navbar-brand text-uppercase d-lg-none text-expanded" href="#">Barbershop brest</a><button data-toggle="collapse" data-target="#navbarResponsive" class="navbar-toggler" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="nav navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="Home.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About us</a></li>
                    <li class="nav-item"><a class="nav-link" href="products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="store.php">Date</a></li>
                    <?php
                    if (isset($_SESSION['nom'])) { // If the client is logged in, He can reserve online
                        echo "<li class='nav-item'><a class='nav-link' href='reserve_online.php'>Reserve Online</a></li>";
                        echo "<li class='nav-item'><a class='nav-link' href='logout.php'>Logout</a></li>";
                    } else
                        echo "<li class='nav-item'><a class='nav-link' href='store-1.php'>Login</a></li>";
                    ?>

                </ul>
            </div>
        </div>
    </nav>
    <section class="page-section cta">
        <div class="container">
            <!-- Here is the date of our shop opened -->
            <div class="row">
                <div class="col-xl-9 mx-auto">
                    <div class="cta-inner text-center rounded">
                        <h2 class="section-heading mb-5"><span class="section-heading-upper">Come On In</span><span class="section-heading-lower">We're Open</span></h2>
                        <ul class="list-unstyled mx-auto list-hours mb-5 text-left">
                            <li class="d-flex list-unstyled-item list-hours-item">Sunday<span class="ml-auto">Closed</span></li>
                            <li class="d-flex list-unstyled-item list-hours-item">Monday<span class="ml-auto">7:00 AM to 8:00 PM</span></li>
                            <li class="d-flex list-unstyled-item list-hours-item">Tuesday<span class="ml-auto">7:00 AM to 8:00 PM</span></li>
                            <li class="d-flex list-unstyled-item list-hours-item">Wednesday<span class="ml-auto">7:00 AM to 8:00 PM</span></li>
                            <li class="d-flex list-unstyled-item list-hours-item">Thursday<span class="ml-auto">7:00 AM to 8:00 PM</span></li>
                            <li class="d-flex list-unstyled-item list-hours-item">Friday<span class="ml-auto">7:00 AM to 8:00 PM</span></li>
                            <li class="d-flex list-unstyled-item list-hours-item">Saturday<span class="ml-auto">7:00 AM to 8:00 PM</span></li>
                        </ul>
                        <p class="address mb-5"><em><strong>2 Rue Siam Street</strong><span><br>Brest</span></em></p>
                        <p class="address mb-0"><small><em>Call Anytime</em></small><span><br>(317) 585-8468</span></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="page-section about-heading">
        <div class="container"><img class="img-fluid rounded about-heading-img mb-3 mb-lg-0" src="assets/img/55.jpg">
            <div class="about-heading-content"></div>
        </div>
    </section>
    <div class="contact-clean">
        <form data-bss-recipient="8b9eedbcf24bb996493af327ec429e10">
            <!-- Here when the client can right a message feeding by his opinion and feedback where I will receive on my email directly -->
            <h2 class="text-center">Send your feedback!!</h2>
            <div class="form-group"><input class="form-control" type="text" name="name" placeholder="Name" required=""></div>
            <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email" required=""></div>
            <div class="form-group"><textarea class="form-control" name="message" placeholder="Message" rows="14" required=""></textarea></div>
            <div class="form-group"><button class="btn btn-primary" type="submit">send </button></div>
        </form><iframe allowfullscreen="" frameborder="0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyBpKeGZiwBeTI79nOuGkXtQQOkhC75oACo&amp;q=2+Rue+Siam+Brest%2C+France&amp;zoom=10" width="100%" height="400"></iframe>
    </div><!-- And here is the location of the shop found on Google Maps-->
    <footer class="footer text-faded text-center py-5">
        <div class="container">
            <p class="m-0 small">Copyright&nbsp;©&nbsp;Barbershop Brest 2020</p>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/smart-forms.min.js"></script>
    <script src="assets/js/current-day.js"></script>
</body>

</html>