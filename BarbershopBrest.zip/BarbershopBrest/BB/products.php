<?php
session_start(); //Start the session

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Products - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
</head>

<body style="background: linear-gradient(rgba(47, 23, 15, 0.65), rgba(47, 23, 15, 0.65)), url('assets/img/chops.jpg');">
    <h1 class="text-center text-white d-none d-lg-block site-heading">
        <span class="text-primary site-heading-upper mb-3"></span>
        <span class="site-heading-lower">Barbershop brest</span>
        <span class="text-primary site-heading-upper mb-3"><?php if (isset($_SESSION['nom'])) echo "Welcome {$_SESSION['nom']}"  ?></span></h1>
    <!--When the user is logged in, His name will appear on every page with Welcome"his name" -->
    <nav class="navbar navbar-light navbar-expand-lg bg-dark py-lg-4" id="mainNav">
        <div class="container"><a class="navbar-brand text-uppercase d-lg-none text-expanded" href="#">Barbershop brest</a><button data-toggle="collapse" data-target="#navbarResponsive" class="navbar-toggler" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="nav navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="Home.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About us</a></li>
                    <li class="nav-item"><a class="nav-link" href="products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="store.php">Date</a></li>
                    <?php
                    if (isset($_SESSION['nom'])) { // If the client is logged in, He can reserve online
                        echo "<li class='nav-item'><a class='nav-link' href='reserve_online.php'>Reserve Online</a></li>";
                        echo "<li class='nav-item'><a class='nav-link' href='logout.php'>Logout</a></li>";
                    } else
                        echo "<li class='nav-item'><a class='nav-link' href='store-1.php'>Login</a></li>";
                    ?>

                </ul>
            </div>
        </div>
    </nav>
    <section class="page-section">
        <div class="container">
            <div class="product-item">
                <!-- Here are some products found in the shop where the client can see -->
                <div class="d-flex product-item-title">
                    <div class="d-flex mr-auto bg-faded p-5 rounded">
                        <h2 class="section-heading mb-0"><span class="section-heading-lower">keep clean</span></h2>
                    </div>
                </div><img class="img-fluid d-flex mx-auto product-item-img mb-3 mb-lg-0 rounded" src="assets/img/Products.jpg">
                <div class="bg-faded p-5 rounded">
                    <p class="mb-0">Hot Product Men Apron Beard King Bib Hair Clips Catcher Grooming Cape Shaving Cloth Hairdressing Shaving Clean Cloth Beard Catcher Bathroom Tool<br></p>
                </div>
            </div>
        </div>
    </section>
    <section class="page-section">
        <div class="container">
            <div class="product-item">
                <div class="d-flex product-item-title">
                    <div class="d-flex ml-auto bg-faded p-5 rounded">
                        <h2 class="section-heading mb-0"><span class="section-heading-lower">wax and gel</span></h2>
                    </div>
                </div><img class="img-fluid d-flex mx-auto product-item-img mb-3 mb-lg-0 rounded" src="assets/img/product2.jpg">
                <div class="bg-faded p-5 rounded">
                    <p class="mb-0">Our seasonal menu features delicious snacks, baked goods, and even full meals perfect for breakfast or lunchtime. We source our ingredients from local, oragnic farms whenever possible, alongside premium vendors for specialty goods.</p>
                </div>
            </div>
        </div>
    </section>
    <section class="page-section">
        <div class="container">
            <div class="product-item">
                <div class="d-flex product-item-title">
                    <div class="d-flex mx-auto bg-faded p-5 rounded">
                        <h2 class="section-heading mb-0"><span class="section-heading-lower">Rose Gold Cutting Mower<br></span></h2>
                    </div>
                </div><img class="img-fluid d-flex mx-auto product-item-img mb-3 mb-lg-0 rounded" src="assets/img/products3.jpg">
                <div class="bg-faded p-5 rounded">
                    <p class="mb-0">The ROSEFX8700 cutting clipper combines power, cut quality and ergonomics for a service that meets the expectations of demanding barbers and hairdressers.<br></p>
                </div>
            </div>
        </div>
    </section>
    <footer class="footer text-faded text-center py-5">
        <div class="container">
            <p class="m-0 small">Copyright&nbsp;©&nbsp;Barbershop Brest 2020</p>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/smart-forms.min.js"></script>
    <script src="assets/js/current-day.js"></script>
</body>

</html>