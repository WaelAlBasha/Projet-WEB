<?php
session_start(); //Starting the session
if (isset($_REQUEST['btnSubmit'])) { // When the submit button is clicked
    $nom = $_REQUEST['txtName']; // we are taking the name written in the textbox
    $email = $_REQUEST['txtEmail']; // we are taking the email written in the textbox 
    $pass = $_REQUEST['txtPass']; // we are taking the password written in the textbox
    $type = $_REQUEST['radio']; //we are taking the checked radio button
    require_once("connexion.php"); //requiring the connection

    $sql = "insert into user (email,nom,password,type) values('$email','$nom','$pass','$type')"; // And inserting them to the user table in the database
    mysqli_query($link, $sql);
    if (mysqli_affected_rows($link) > 0) {
        $_SESSION['nom'] = $nom;
        $_SESSION['email'] = $email;
        $_SESSION['password'] = $pass;
        $_SESSION['type'] = $type;
        header("location:store-1.php");
    } else {
        echo "<script>alert('user already exist')</script>";
    }
} else {
    $nom = $email = $pass = $type = "";
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Home - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
</head>

<body style="background: linear-gradient(rgba(47, 23, 15, 0.65), rgba(47, 23, 15, 0.65)), url('assets/img/chops.jpg');">
    <h1 class="text-center text-white d-none d-lg-block site-heading"><span class="site-heading-lower">Barbershop brest</span></h1>
    <nav class="navbar navbar-light navbar-expand-lg bg-dark py-lg-4" id="mainNav">
        <div class="container"><a class="navbar-brand text-uppercase d-lg-none text-expanded" href="#">Brand</a><button data-toggle="collapse" data-target="#navbarResponsive" class="navbar-toggler" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="nav navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="Home.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About us</a></li>
                    <li class="nav-item"><a class="nav-link" href="products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="store.php">Date</a></li>
                    <li class="nav-item"><a class="nav-link" href="store-1.php">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="row register-form">
        <div class="col-md-8 offset-md-2">
            <form class="custom-form" method="post">
                <h1>Register Form</h1>
                <div class="form-row form-group">
                    <div class="col-sm-4 label-column"><label class="col-form-label" for="name-input-field">Name </label></div>
                    <div class="col-sm-6 input-column"><input class="form-control" type="text" required="" name="txtName"></div>
                </div>
                <div class="form-row form-group">
                    <div class="col-sm-4 label-column"><label class="col-form-label" for="email-input-field">Email </label></div>
                    <div class="col-sm-6 input-column"><input class="form-control" type="email" required="" name="txtEmail"></div>
                </div>
                <div class="form-row form-group">
                    <div class="col-sm-4 label-column"><label class="col-form-label" for="pawssword-input-field">Password </label></div>
                    <div class="col-sm-6 input-column"><input class="form-control" type="password" required="" name="txtPass"></div>
                </div>
                <div class="form-row form-group">
                    <div class="col-sm-4 label-column"><label class="col-form-label" for="repeat-pawssword-input-field">Repeat Password </label></div>
                    <div class="col-sm-6 input-column"><input class="form-control" type="password" required="" name="txtRPass"></div>
                </div>
                <div class="form-row form-group">
                    <table style="margin-left:auto; margin-right:auto;">
                        <tr>
                            <td>
                                <label><input type="radio" name="radio" value="Student">Student
                                </label>
                            </td>
                            <td><label>
                                    <input type="radio" name="radio" value="Not-Student">Not-Student
                                </label>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="form-check"><input class="form-check-input" type="checkbox" id="formCheck-1" required="">
                    <label class="form-check-label" for="formCheck-1">I've read and accept the terms and conditions</label></div>
                <button class="btn btn-light submit-button" type="submit" style="filter: blur(0px);" name="btnSubmit">Submit Form</button>
            </form>
        </div>
    </div>
    <section class="page-section clearfix">
        <div class="container">
            <div class="intro"></div>
        </div>
    </section>
    <footer class="footer text-faded text-center py-5">
        <div class="container">
            <p class="m-0 small">Copyright&nbsp;©&nbsp;Barbershop Brest 2020</p>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/smart-forms.min.js"></script>
    <script src="assets/js/current-day.js"></script>
</body>

</html>