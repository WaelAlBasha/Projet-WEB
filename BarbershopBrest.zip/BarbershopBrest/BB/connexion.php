<?php
$link = mysqli_connect("localhost", "root", "", "clients"); //Here is the connection that connects the database"clients" with the local host
//And that can be used by session in every page
if ($link == false)
    die("Connexion ERROR! :" . mysqli_connect_error());
